
Do not use anything in this directory
-------------------------------------

It is badly named and will be changed soon.

This directory currently holds parts of the Java/Processing library and
the HTML for the Blink1Control Windows & Mac applications.

You're probably looking for something else.

- blink1-lib C library source -- look in blink1/commandline/

- Blink1Lib .NET library source -- look in blink1/windows/Blink1Lib/

- Java/Procesing library source -- look in blink1/java/



