Example blink(1) Processing Sketches
====================================

These are examples of how to use the blink(1) Processing/Java library.

If you want a ready-to-run version of the Processing library with examples included, download:

http://thingm.com/blink1/downloads/blink1-java-processing-lib.zip 


Installing the blink(1) Processing library
------------------------------------------
Installation follows standard Processing third-party library installation techniques:

0. Quit Processing 
1. Grab zipfile http://thingm.com/blink1/downloads/blink1-java-processing-lib.zip 
2. Unzip it, it will create a folder called "blink1" 
3. Put that folder inside the folder "~/Documents/Processing/libraries" (on Mac)
4. The result will be "~/Documents/Processing/libraries/blink1" 
5. Run Processing. Go to "Examples" menu and you should find several "blink1" examples in the list.
